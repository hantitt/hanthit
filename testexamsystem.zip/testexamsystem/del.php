<?php
  include("dbconnect.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	mysql_query("DELETE FROM admin_tbl WHERE id = '$id'")
	or die(mysql_error());  	
	
	header("Location: backend.php");
?>