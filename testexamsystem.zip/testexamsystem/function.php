<?php
class USER{
	private $db;
	function __construct($conn)
	{
		$this->db =$conn;
	}

	public function getData($query){
		$exam = $this->db->prepare($query);
		$exam->execute();
		$row=$exam->fetchAll();
		return $row;
	}

	public function login($username, $password){
		
		
		try {
			$exam = $this->db->prepare("SELECT * FROM student_tbl WHERE username = :username LIMIT 1");
			$exam->execute(array(':username'=>$username));
			$userRow = $exam->fetch(PDO::FETCH_ASSOC);

			if ($exam->rowCount() > 0) {
				if ($userRow['password'] == $password) {
					session_start();
					// $_SESSION['student_id'] = $userRow['student_id'];
					// $_SESSION['fullname'] = $userRow['fullname'];
					// $_SESSION['gender'] = $userRow['gender'];
					$_SESSION['username'] = $userRow['username'];
					$_SESSION['password'] = $userRow['password'];
					// $_SESSION['score'] = $userRow['score'];
					// $_SESSION['status'] = $userRow['status'];
					// $_SESSION['date'] = $userRow['date'];
					// $_SESSION['profileurl'] = $userRow['profileurl'];

					return true;
				}
				else {
					return false;
				}
			}

		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}



	public function addadmin($insertAdminuser, $insertAdminpass){

		try {
			$exam = $this->db->prepare("INSERT INTO admin_tbl(adminuser, adminpass) VALUES (:adminuser, :adminpass)");


			$exam->bindparam(":adminuser", $insertAdminuser);
			$exam->bindparam(":adminpass", $insertAdminpass);
			


			$exam->execute();
			return true;
		
		} 
		catch (PDOException $e) 
		{
			echo $e->getMessage();
			return false;
		}
	}

// question list
	public function addQuestion($ques_name,$ques_opt1,$ques_opt2,$ques_opt3,$ques_ans){

		try {
			$exam = $this->db->prepare("INSERT INTO question(question, option1, option2,option3,answer) VALUES (:question, :option1, :option2, :option3, :answer)");


			$exam->bindparam(":question", $question);
			$exam->bindparam(":option1", $option1);
			$exam->bindparam(":option2", $option2);
			$exam->bindparam(":option3", $option3);
			$exam->bindparam(":answer", $answer);
			
		
			$exam->execute();
			return true;
		
		} 
		catch (PDOException $e) 
		{
			echo $e->getMessage();
			return false;
		}
	}




//studentlist
public function addStudent($fullname,$gender,$username,$password,$score,$status,$date,$profileurl){

		try {
			$exam = $this->db->prepare("INSERT INTO student_tbl(fullname,gender,username,password,score,status,date,profileurl) VALUES (:fullname, :gender, :username, :password, :score, :status, :date, :profileurl)");


			$exam->bindparam(":fullname", $fullname);
			$exam->bindparam(":gender", $gender);
			$exam->bindparam(":username", $username);
			$exam->bindparam(":password", $password);
			$exam->bindparam(":score", $score);
			$exam->bindparam(":status", $status);
			$exam->bindparam(":date", $date);
			$exam->bindparam(":profileurl", $profileurl);
			
		
			$exam->execute();
			return true;
		
		} 
		catch (PDOException $e) 
		{
			echo $e->getMessage();
			return false;
		}
	}




	

	
	//////////ADMIN//////
	public function adminLogin($username, $password){

		
		try {
			$exam = $this->db->prepare("SELECT * FROM admin_tbl WHERE adminuser = :adminuser LIMIT 1");
			$exam->execute(array(':adminuser'=>$username));
			$userRow = $exam->fetch(PDO::FETCH_ASSOC);

			if ($exam->rowCount() > 0) {
				if ($userRow['adminpass'] == $password) {
					session_start();
					$_SESSION['adminuser'] = $userRow['adminuser'];
					$_SESSION['adminpass'] = $userRow['adminpass'];

					return true;
				}
				else {
					return false;
				}
			}

		} catch (PDOException $e) {
			echo $e->getMessage();
			return false;
		}
	}

	public function logout(){
		session_destroy();
		return true;
	}




	/*=========================*/

// 	public function deleteAdmin($id,$username,$password){
// 		try{
//     $query = $pdo->prepare("delete from people where username = :username");
//     $query->execute(array(
//     ':username' => 'admin.edu'
//     ));
//     echo "Data successfully deleted in the database table ... ";
//     }catch(PDOException $e){
//     echo "Failed to delete the MySQL database table ... :".$e->getMessage();
//     }
// }




/*upDATE*/

	// public function updateAdmin($username,$password){
	// 	try{
 //    $query = $pdo->prepare("update people set country = :country where email = :email");
 //    $data = array(
 //    ':country' => 'Canada',
 //    ':email' => 'robby@world.edu'
 //    );
 //    $query->execute($data);
 //    echo "Data successfully updated into the database table ...";
 //    }catch(PDOException $e){
 //    echo "Error! failed to update into the database table ... :".$e->getMessage();
 //    }
	// }


}
?>
