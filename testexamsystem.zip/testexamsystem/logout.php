<?php
include('dbconnect.php');
//logout
if (isset($_GET['logout'])  && $_GET['logout'] == "true")
 {
	$user->logout();
	header("Location:index.php");	
}

?>