<!DOCTYPE html>
<html>
<head>
	<title><h1>Exam for Students</h1></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/mystyle1.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min."></script>
</head>
<body>
	<div>
		<h1>Exam for Students</h1>
		<h3>Student's profile</h3>
	</div>
	<div>
		<table class="tbll1">
			<tr>
				<td>Name</td>
			</tr>

			<tr>
				<td>Gender</td>
			</tr>

			<tr>
				<td>Pasword</td>
			</tr>

		</table><br>
	</div>
	<div class="row row1">
		<div class="col-sm-6 one">
			<h1>Test for HTML</h1>
		</div>

		<div class="col-sm-6">
			<a href="htmlquestion.php"><button class="btn  btn-default">START TEST</button></a>
		</div>
	</div>
	
		
	

</body>
</html>