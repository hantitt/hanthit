<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* CI MCS Extension
* 
* Controller admin > accounts.php to be used with CI MCS Extension
* 
* @package		CI MCS Extension
* @author		Jason Davey
* @copyright	Copyright (C) 2015 Frozen Tiger Ltd.
* @license		http://www.exoiz.com/mcs_license
* @Version		3.0.0
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/

class Accounts extends MX_Controller
{
	
	public function index()
	{
		if ($this->session->userdata('user_id')==''){
			header('Location: '.url('home'));
		}else{
			$data = array();
			$data['userinfo'] = $this->master->get_userinfo();
			if ($data['userinfo']['account']['account_admin']=='1'){
				header('Location: '.url('admin/accounts/s'));
			}else{
				header('Location: '.url('home'));
			}
		}
	}
	
	public function s(){
		if ($this->session->userdata('user_id')==''){
			header('Location: '.url('home'));
		}else{
			$data = array();
			$data['userinfo'] = $this->master->get_userinfo();
			if ($data['userinfo']['account']['account_admin']=='1'){
				$data['search'] = urldecode(($this->uri->segment(5)!='' ? $this->uri->segment(5) : 'search'));
				$data['sortfield'] = ($this->uri->segment(6)!='' ? $this->uri->segment(6) : 'default');
				$data['sort'] = ($this->uri->segment(7)!='' ? $this->uri->segment(7) : 'sort');
				$data['limit'] = ($this->uri->segment(8)!='' ? $this->uri->segment(8) : 20);
				$data['page_num'] = ($this->uri->segment(9)!='' ? $this->uri->segment(9) : 1);
				$data['account_data'] = $this->master->get_accounts($data['limit'],'',$data['page_num'],$data['search'],$data['sortfield'],$data['sort']);
				$this->load->library('pagination');
				$config['uri_segment'] = 9;
				$config['num_links'] = 2;
				$config['base_url'] = url('admin/accounts/s/'.$data['search'].'/'.$data['sortfield'].'/'.$data['sort'].'/'.$data['limit']);
				$config['total_rows'] = $data['account_data']['total_rows'];
				$config['per_page'] = $data['limit'];
				$config['use_page_numbers'] = TRUE;
				$this->pagination->initialize($config);
				$data['pagination_links'] = $this->pagination->create_links();
				$data['meta']['title'] = 'Admin &gt; Accounts';
				$theme = $this->master->get_theme();
				$this->load->view($theme.'/admin/accounts',$data);
			}else{
				header('Location: '.url('home'));
			}
		}
	}
	
	public function users()
	{
		if ($this->session->userdata('user_id')==''){
			header('Location: '.url('home'));
		}else{

			$data = array();
			$data['userinfo'] = $this->master->get_userinfo();
			if ($data['userinfo']['account']['account_admin']=='1'){
				if ($this->uri->segment(5)=='s'){
					$data['account_id'] = $this->uri->segment(6);
					$data['search'] = urldecode(($this->uri->segment(7)!='' ? $this->uri->segment(7) : 'search'));
					$data['sortfield'] = ($this->uri->segment(8)!='' ? $this->uri->segment(8) : 'default');
					$data['sort'] = ($this->uri->segment(9)!='' ? $this->uri->segment(9) : 'sort');
					$data['limit'] = ($this->uri->segment(10)!='' ? $this->uri->segment(10) : 20);
					$data['page_num'] = ($this->uri->segment(11)!='' ? $this->uri->segment(11) : 1);
					$data['user_data'] = $this->master->get_users($data['account_id'],$data['limit'],'',$data['page_num'],$data['search'],$data['sortfield'],$data['sort']);
					$this->load->library('pagination');
					$config['uri_segment'] = 11;
					$config['num_links'] = 2;
					$config['base_url'] = url('admin/accounts/users/s/'.$data['account_id'].'/'.$data['search'].'/'.$data['sortfield'].'/'.$data['sort'].'/'.$data['limit']);
					$config['total_rows'] = $data['user_data']['total_rows'];
					$config['per_page'] = $data['limit'];
					$config['use_page_numbers'] = TRUE;
					$this->pagination->initialize($config);
					$data['pagination_links'] = $this->pagination->create_links();
					$data['meta']['title'] = 'Admin &gt; Accounts &gt; Users';
					$theme = $this->master->get_theme();
					$this->load->view($theme.'/admin/accounts/users',$data);
				}
				if ($this->uri->segment(5)=='info'){
					$data['user_id'] = $this->uri->segment(6);
					$data['user_data'] = $this->master->get_userinfo($data['user_id']);
					$data['meta']['title'] = 'Admin &gt; Accounts &gt; Users &gt; Info';
					$theme = $this->master->get_theme();
					$this->load->view($theme.'/admin/accounts/users/info',$data);
				}
			}else{
				header('Location: '.url('home'));
			}
		}
			
	}
	
}

/* End of file tasks.php */
/* Location: ./application/controllers/tasks.php */