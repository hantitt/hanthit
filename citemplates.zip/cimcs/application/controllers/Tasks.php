<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* CI MCS Extension
* 
* Controller tasks.php to be used with CI MCS Extension
* 
* @package		CI MCS Extension
* @author		Jason Davey
* @copyright	Copyright (C) 2015 Frozen Tiger Ltd.
* @license		http://www.exoiz.com/mcs_license
* @Version		3.0.0
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/

class Tasks extends MX_Controller
{
	
	public function index()
	{
		if ($this->session->userdata('user_id')==''){
			header('Location: '.url('home'));
		}else{
			header('Location: '.url('tasks/s'));
		}
	}
	
	public function s(){
		if ($this->session->userdata('user_id')==''){
			header('Location: '.url('home'));
		}else{
			$data = array();
			$data['search'] = urldecode(($this->uri->segment(4)!='' ? $this->uri->segment(4) : 'search'));
			$data['sortfield'] = ($this->uri->segment(5)!='' ? $this->uri->segment(5) : 'default');
			$data['sort'] = ($this->uri->segment(6)!='' ? $this->uri->segment(6) : 'sort');
			$data['limit'] = ($this->uri->segment(7)!='' ? $this->uri->segment(7) : 20);
			$data['page_num'] = ($this->uri->segment(8)!='' ? $this->uri->segment(8) : 1);
			$data['task_data'] = $this->master->get_tasks($data['limit'],'',$data['page_num'],$data['search'],$data['sortfield'],$data['sort']);
			$this->load->library('pagination');
			$config['uri_segment'] = 8;
			$config['num_links'] = 2;
			$config['base_url'] = url('tasks/s/'.$data['search'].'/'.$data['sortfield'].'/'.$data['sort'].'/'.$data['limit']);
			$config['total_rows'] = $data['task_data']['total_rows'];
			$config['per_page'] = $data['limit'];
			$config['use_page_numbers'] = TRUE;
			$this->pagination->initialize($config);
			$data['pagination_links'] = $this->pagination->create_links();
			$data['meta']['title'] = 'Tasks';
			$theme = $this->master->get_theme();
			$this->load->view($theme.'/tasks',$data);
		}
	}
	
	public function info()
	{
		if ($this->session->userdata('user_id')=='' || !is_num($this->uri->segment(4)) || !$this->master->access_check('task','tasks',$this->uri->segment(4))){
			header('Location: '.url('home'));
		}else{
			$data = array();
			$task_id = $this->uri->segment(4);
			$data['task_data'] = $this->master->get_tasks('',$task_id);
			$data['task_detail_data'] = $this->master->get_task_details($task_id);
			$data['meta']['title'] = 'Task Details';
			$theme = $this->master->get_theme();
			$this->load->view($theme.'/tasks/info',$data);
		}
	}
	
}

/* End of file tasks.php */
/* Location: ./application/controllers/tasks.php */