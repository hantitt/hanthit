<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* CI MCS Extension
* 
* Model selects.php to be used with CI MCS Extension
* 
* @package		CI MCS Extension
* @author		Jason Davey
* @copyright	Copyright (C) 2015 Frozen Tiger Ltd.
* @license		http://www.exoiz.com/mcs_license
* @Version		3.0.0
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/

class Selects extends CI_Model
{

	function create_select($name,$extra='',$selected='',$select='',$default='',$first_option=1){
		$html = '<select name="'.$name.'" id="'.$name.'"'.$extra.'>';
		if (is_array($default)){
			$html.= '<option value="'.$default['key'].'">'.$default['value'].'</option>';
		}else{
			if ($first_option==1){
				$html.= '<option value="0">- Select -</option>';
			}
		}
		foreach ($select as $key => $value) {
			if ($selected==$key){
				$html.= '<option value="'.$key.'" SELECTED>'.$value.'</option>';
			}else{
				$html.= '<option value="'.$key.'">'.$value.'</option>';
			}
		}
		$html.= '</select>';
		return $html;
	}
	
	function language($name,$extra='',$selected='',$static='0'){
		$select=array();
		$select['en'] 	= 'English';
		$select['fr'] 	= 'Français';
		if ($static=='1'){
			if (array_key_exists($selected,$select)){
				return $select[$selected];
			}else{
				return '';
			}
		}else if ($static=='2'){
			return array_search(strtolower($selected), array_map('strtolower', $select));
		}else{
			return $this->create_select($name,$extra,$selected,$select,'',0);
		}
	}
	
	function theme($name,$extra='',$selected='',$static='0'){
		$select=array();
		$select['default'] 	= 'Default';
		if ($static=='1'){
			if (array_key_exists($selected,$select)){
				return $select[$selected];
			}else{
				return '';
			}
		}else if ($static=='2'){
			return array_search(strtolower($selected), array_map('strtolower', $select));
		}else{
			return $this->create_select($name,$extra,$selected,$select,'',0);
		}
	}
	
	function task_status($name,$extra='',$selected='',$static='0'){
		$select=array();
		$select['0'] 	= 'Waiting';
		$select['1'] 	= 'In Progress';
		$select['2'] 	= 'Complete';
		if ($static=='1'){
			if (array_key_exists($selected,$select)){
				return $select[$selected];
			}else{
				return '';
			}
		}else if ($static=='2'){
			return array_search(strtolower($selected), array_map('strtolower', $select));
		}else{
			return $this->create_select($name,$extra,$selected,$select,'',0);
		}
	}

	function users($name,$extra='',$selected='',$static='0'){
		if ($static=='1'){
			$query = $this->db
			->select('user_firstname')
			->from('users')
			->where('user_id',(string)$selected)
			->limit(1)
			->get();
			if ($query->num_rows()>0){
				$users = $query->row_array();
				return $users['user_firstname'];
			}else{
				return 'User not found!';
			}
		}else{
			$html = '<select name="'.$name.'" id="'.$name.'"'.$extra.'><option value="0">- Select -</option>';
			$query = $this->db
			->select('user_id,user_firstname')
			->from('users')
			->where('account_id',(string)$this->session->userdata('account_id'))
			->order_by('user_firstname', 'ASC')
			->get();
			if ($query->num_rows()>0){
				foreach ($query->result_array() as $u_key => $users){
					if ($selected==$users['user_id']){
						$html.= '<option value="'.$users['user_id'].'" SELECTED>'.$users['user_firstname'].'</option>';
					}else{
						$html.= '<option value="'.$users['user_id'].'">'.$users['user_firstname'].'</option>';
					}
				}
			}
			$html.= '</select>';
			return $html;
		}
	}

}

/* End of file selects.php */
/* Location: ./public_html/application/models/selects.php */