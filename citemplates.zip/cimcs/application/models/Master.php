<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* CI MCS Extension
* 
* Model master.php to be used with CI MCS Extension
* 
* @package		CI MCS Extension
* @author		Jason Davey
* @copyright	Copyright (C) 2015 Frozen Tiger Ltd.
* @license		http://www.exoiz.com/mcs_license
* @Version		3.0.0
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/

class Master extends CI_Model
{

	function site_settings()
	{
		$data = array();
		$query = $this->db
		->from('site_settings')
		->limit(1)
		->get();
		if ($query->num_rows()>0){
			$site_settings = $query->result_array();
			$site_settings = $site_settings[0];
		}
		return $site_settings;
	}
	
	function get_userinfo($user_id_force='')
	{
		$data = array();
		$account_id = $this->session->userdata('account_id');
		$user_id = $this->session->userdata('user_id');
		$this->db->from('users');
		if ($user_id_force==''){
			$this->db->where('account_id',(string)$account_id);
			$this->db->where('user_id',(string)$user_id);
		}else{
			$this->db->where('user_id',(string)$user_id_force);
		}
		$this->db->where('user_current','1');
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows()>0){
			$users = $query->result_array();
			$data['user'] = $users[0];
		}else{
			$users = $this->db->list_fields('users');
			for ($i=0; $i < count($users); $i++) { 
				$data['user'][$users[$i]] = '';
			}
		}
		$this->db->from('accounts');
		if ($user_id==''){
			$this->db->where('account_id',(string)$account_id);
		}else{
			$this->db->where('account_id',(string)$data['user']['account_id']);
		}
		$this->db->where('account_current','1');
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows()>0){
			$accounts = $query->result_array();
			$data['account'] = $accounts[0];
		}else{
			$accounts = $this->db->list_fields('users');
			for ($i=0; $i < count($accounts); $i++) { 
				$data['account'][$accounts[$i]] = '';
			}
		}
		return $data;
	}
	
	function get_theme()
	{
		$userinfo = $this->get_userinfo();
		return ($userinfo['user']['user_theme']=='' ? 'default' : $userinfo['user']['user_theme']);
	}
	
	function get_stats()
	{
		$data = array();
		$account_id = $this->session->userdata('account_id');
		$user_id = $this->session->userdata('user_id');
		$query = $this->db
		->select('task_id')
		->from('tasks')
		->where('account_id',(string)$account_id)
		->where('task_status !=','2')
		->where('task_assigned',(string)$user_id)
		->where('task_current','1')
		->get();
		$data['my_active_tasks'] = $query->num_rows();
		$query = $this->db
		->select('task_id')
		->from('tasks')
		->where('account_id',(string)$account_id)
		->where('task_status !=','2')
		->where('task_current','1')
		->get();
		$data['active_tasks'] = $query->num_rows();
		$query = $this->db
		->select('user_id')
		->from('users')
		->where('account_id',(string)$account_id)
		->where('user_current','1')
		->get();
		$data['active_users'] = $query->num_rows();
		return $data;
	}
	
	function access_check($table_single,$table_plural,$table_id){
		$query = $this->db
		->select($table_single.'_id')
		->from($table_plural)
		->where($table_single.'_id', (string)$table_id)
		->where('account_id', (string)$this->session->userdata('account_id'))
		->where($table_single.'_current', '1')
		->limit(1)
		->get();
		if ($query->num_rows()>0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function get_accounts($limit=20,$account_id=0,$page_num=1,$search='',$sortfield='default',$sort='sort')
	{
		$data = array();
		$sortable_fields = array('id'=>'a.account_id','name'=>'a.account_name','updated'=>'a.account_modified');
		$offset = ($page_num==1) ? 0 : ($page_num*$limit)-$limit;
		if ($account_id!=0){
			$this->db->select('a.account_id, a.account_name, a.account_modified');
		}else{
			$this->db->select('SQL_CALC_FOUND_ROWS a.account_id, a.account_name, a.account_modified', FALSE);	
		}
		if ($account_id!=0){
			$this->db->where('a.account_id',(string)$account_id);
		}
		$this->db->where('a.account_current','1');
		$this->db->from('accounts a');
		if ($account_id!=0){
			$this->db->limit(1);
		}else{
			$this->db->limit($limit,$offset);
		}
		if (array_key_exists($sortfield,$sortable_fields) && ($sort=='asc' || $sort=='desc')){
			$this->db->order_by($sortable_fields[$sortfield],strtoupper($sort));
		}else{
			$this->db->order_by('a.account_name ASC, a.account_id DESC');
		}
		$query = $this->db->get();
		// echo $this->db->last_query();
		if ($query->num_rows()>0){
			$accounts = $query->result_array();
			if ($account_id!=0){
				$data['account'] = $accounts[0];
			}else{
				$data['accounts'] = $accounts;
			}
			$query = $this->db->query('SELECT FOUND_ROWS() AS `Count`');
			$data["total_rows"] = $query->row()->Count;
		}else{
			$data["total_rows"] = '0';
		}
		return $data;	
	}
	
	function get_users($account_id,$limit=20,$user_id=0,$page_num=1,$search='',$sortfield='default',$sort='sort')
	{
		$data = array();
		$sortable_fields = array('id'=>'u.user_id','firstname'=>'u.user_firstname','lastname'=>'u.user_lastname','email'=>'u.user_email','updated'=>'u.user_modified');
		$offset = ($page_num==1) ? 0 : ($page_num*$limit)-$limit;
		if ($user_id!=0){
			$this->db->select('u.user_id, u.user_firstname, u.user_lastname, u.user_email, u.user_modified');
		}else{
			$this->db->select('SQL_CALC_FOUND_ROWS u.user_id, u.user_firstname, u.user_lastname, u.user_email, u.user_modified', FALSE);	
		}
		if ($user_id!=0){
			$this->db->where('u.user_id',(string)$user_id);
		}
		$this->db->where('u.account_id',(string)$account_id);
		$this->db->where('u.user_current','1');
		$this->db->from('users u');
		if ($user_id!=0){
			$this->db->limit(1);
		}else{
			$this->db->limit($limit,$offset);
		}
		if (array_key_exists($sortfield,$sortable_fields) && ($sort=='asc' || $sort=='desc')){
			$this->db->order_by($sortable_fields[$sortfield],strtoupper($sort));
		}else{
			$this->db->order_by('u.user_firstname ASC, u.user_id DESC');
		}
		$query = $this->db->get();
		// echo $this->db->last_query();
		if ($query->num_rows()>0){
			$users = $query->result_array();
			if ($user_id!=0){
				$data['user'] = $users[0];
			}else{
				$data['users'] = $users;
			}
			$query = $this->db->query('SELECT FOUND_ROWS() AS `Count`');
			$data["total_rows"] = $query->row()->Count;
		}else{
			$data["total_rows"] = '0';
		}
		return $data;	
	}
	
	function get_tasks($limit=20,$task_id=0,$page_num=1,$search='',$sortfield='default',$sort='sort')
	{
		$data = array();
		$sortable_fields = array('id'=>'t.task_id','descr'=>'t.task_descr','status'=>'t.task_status','creator'=>'t.task_creator','assigned'=>'task_assigned','updated'=>'t.task_modified');
		$account_id = $this->session->userdata('account_id');
		$offset = ($page_num==1) ? 0 : ($page_num*$limit)-$limit;
		if ($task_id!=0){
			$this->db->select('t.task_id, t.task_descr, t.task_status, u1.user_firstname as task_creator, u2.user_firstname as task_assigned, t.task_modified');
		}else{
			$this->db->select('SQL_CALC_FOUND_ROWS t.task_id, t.task_descr, t.task_status, u1.user_firstname as task_creator, u2.user_firstname as task_assigned, t.task_modified', FALSE);	
		}
		if ($task_id!=0){
			$this->db->where('t.task_id',(string)$task_id);
		}
		$this->db->where('t.account_id',(string)$account_id);
		$this->db->where('t.task_current','1');
		$this->db->from('tasks t');
		$this->db->join('users u1', 't.task_creator = u1.user_id', 'inner');
		$this->db->join('users u2', 't.task_assigned = u2.user_id', 'inner');
		if ($task_id!=0){
			$this->db->limit(1);
		}else{
			$this->db->limit($limit,$offset);
		}
		if (array_key_exists($sortfield,$sortable_fields) && ($sort=='asc' || $sort=='desc')){
			$this->db->order_by($sortable_fields[$sortfield],strtoupper($sort));
		}else{
			$this->db->order_by('t.task_status ASC, t.task_modified DESC');
		}
		$query = $this->db->get();
		// echo $this->db->last_query();
		if ($query->num_rows()>0){
			$tasks = $query->result_array();
			if ($task_id!=0){
				$data['task'] = $tasks[0];
			}else{
				$data['tasks'] = $tasks;
			}
			$query = $this->db->query('SELECT FOUND_ROWS() AS `Count`');
			$data["total_rows"] = $query->row()->Count;
		}else{
			$data['task']['task_descr'] = 'Unable to find!';
			$data['task']['task_status'] = '0';
			$data["total_rows"] = '0';
		}
		return $data;	
	}
	
	function get_task_details($task_id=0)
	{
		$data = array();
		$account_id = $this->session->userdata('account_id');
		$query = $this->db
		->select('t.task_detail_id, t.task_detail_info, u1.user_firstname as task_detail_author, u2.user_firstname as task_detail_assigned, t.task_detail_modified')
		->where('t.task_id',(string)$task_id)
		->where('t.account_id',(string)$account_id)
		->where('t.task_detail_current','1')
		->from('task_details t')
		->join('users u1', 't.task_detail_author = u1.user_id', 'inner')
		->join('users u2', 't.task_detail_assigned = u2.user_id', 'inner')
		->order_by('task_detail_id','DESC')
		->get();
		if ($query->num_rows()>0){
			$data['task_details'] = $query->result_array();
		}
		return $data;	
	}
	
	function get_task_assigned($task_id=0)
	{
		$data = array();
		$account_id = $this->session->userdata('account_id');
		$query = $this->db
		->select('task_assigned')
		->where('task_id',(string)$task_id)
		->where('account_id',(string)$account_id)
		->where('task_current','1')
		->from('tasks')
		->limit(1)
		->get();
		if ($query->num_rows()>0){
			$task = $query->row_array();
			return $task['task_assigned'];
		}else{
			return 0;
		}
	}
	
}							
/* End of file master.php */
/* Location: ./application/models/master.php */