<?php if (!isset($meta)) $meta=''; echo modules::run('_main/top',$meta); ?>
<script>
function show_add_account(){
	$('#new_user').toggle();
}
function add_user() {
	$.post("<?=url('_ajax/add_user')?>",
		$("#new_user_form").serialize()
	,
	function(data){
		if (data.msg==1){
			refresh_page();
		}else{
			$.each(data.field_data, function(f_key, f_value) {
				$("#div_"+f_key).removeClass('has-error');
				$("#"+f_key).val(f_value);
			});
			$.each(data.error_array, function(e_key, e_value) {
				$("#div_"+e_key).addClass('has-error');
			});
			$('#msg_content').html(data.msg_data);
			$('#msg_container').removeClass('alert-success').addClass('alert-danger').show();
			$('#msg_close_button').show();
		}
	}, 'json');
	return false;
}
</script>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
	<ol class="breadcrumb">
		<li><a href="<?=url('home')?>">Home</a></li>
		<li><a href="<?=url('admin')?>">Admin</a></li>
		<li><a href="<?=url('admin/accounts')?>">Accounts</a></li>
		<li class="active">Users</li>
	</ol>
	<h4 class="page-header">Users</h4>
	<div id="msg_container" class="alert alert-dismissible" role="alert" style="display:none">
	  <button id="msg_close_button" type="button" class="close" onclick="$('#msg_container').hide();" style="display:none">&times;</button>
	  <span id="msg_content"></span>
	</div>
	<?php if ($this->session->flashdata('msg')=='1'){ ?>
		<div id="msg_container2" class="alert alert-success alert-dismissible" role="alert">
		  <button id="msg_close_button2" type="button" class="close" onclick="$('#msg_container2').hide();">&times;</button>
		  <span id="msg_content2"><?=$this->session->flashdata('msg_data')?></span>
		</div>
	<?php } ?>
	<div class="container-fluid well">
		<button class="btn btn-primary" type="button" onclick="show_add_account();">Add new user</button>
		<div id="new_user" style="display:none">
			<div class="clearfix">&nbsp;</div>
			<form id="new_user_form" class="form-horizontal" role="form">
				<div id="div_user_firstname" class="form-group">
					<label for="user_firstname" class="col-sm-2 control-label">First Name</label>
					<div class="col-sm-10">
						<input type="text" id="user_firstname" name="user_firstname" class="form-control input_lg" placeholder="Enter first name">
					</div>
				</div>
				<div id="div_user_lastname" class="form-group">
					<label for="user_lastname" class="col-sm-2 control-label">Last Name</label>
					<div class="col-sm-10">
						<input type="text" id="user_lastname" name="user_lastname" class="form-control input_lg" placeholder="Enter last name">
					</div>
				</div>
				<div id="div_user_email" class="form-group">
					<label for="user_email" class="col-sm-2 control-label">Email</label>
					<div class="col-sm-10">
						<input type="text" id="user_email" name="user_email" class="form-control input_lg" placeholder="Enter email">
					</div>
				</div>
				<div id="div_user_password" class="form-group">
					<label for="user_password" class="col-sm-2 control-label">Password</label>
					<div class="col-sm-10">
						<input type="password" id="user_password" name="user_password" class="form-control input_lg" placeholder="Enter password">
					</div>
				</div>
				<div class="form-group nomarg">
					<div class="col-sm-offset-2 col-sm-10">
						<input type="hidden" id="account_id" name="account_id" value="<?=$account_id?>">
						<button type="button" class="btn btn-success" onclick="add_user();">Add</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="table-responsive">
		<table class="table table-hover table-bordered table_sortable">
			<thead>
				<tr>
					<th class="s_header<?=($sortfield=='id' && $sort=='asc' ? ' s_asc' : ($sortfield=='id' && $sort=='desc' ? ' s_desc' : ''))?>"><a href="<?=url('admin/accounts/users/s/'.$account_id.'/'.$search.'/id/'.($sort!='desc' ? 'desc' : 'asc').'/'.$limit.'/'.$page_num)?>">ID</a></th>
					<th class="s_header<?=($sortfield=='firstname' && $sort=='asc' ? ' s_asc' : ($sortfield=='firstname' && $sort=='desc' ? ' s_desc' : ''))?>"><a href="<?=url('admin/accounts/users/s/'.$account_id.'/'.$search.'/firstname/'.($sort!='desc' ? 'desc' : 'asc').'/'.$limit.'/'.$page_num)?>">First Name</a></th>
					<th class="s_header<?=($sortfield=='lastname' && $sort=='asc' ? ' s_asc' : ($sortfield=='lastname' && $sort=='desc' ? ' s_desc' : ''))?>"><a href="<?=url('admin/accounts/users/s/'.$account_id.'/'.$search.'/lastname/'.($sort!='desc' ? 'desc' : 'asc').'/'.$limit.'/'.$page_num)?>">Last Name</a></th>
					<th class="s_header<?=($sortfield=='email' && $sort=='asc' ? ' s_asc' : ($sortfield=='email' && $sort=='desc' ? ' s_desc' : ''))?>"><a href="<?=url('admin/accounts/users/s/'.$account_id.'/'.$search.'/email/'.($sort!='desc' ? 'desc' : 'asc').'/'.$limit.'/'.$page_num)?>">Email</a></th>
					<th class="s_header<?=($sortfield=='updated' && $sort=='asc' ? ' s_asc' : ($sortfield=='updated' && $sort=='desc' ? ' s_desc' : ''))?>"><a href="<?=url('admin/accounts/users/s/'.$account_id.'/'.$search.'/updated/'.($sort!='desc' ? 'desc' : 'asc').'/'.$limit.'/'.$page_num)?>">Last Updated</a></th>
				</tr>
			</thead>
			<tbody>
			<?php
			if (!empty($user_data['users'])){
			foreach ($user_data['users'] as $u_key => $u_value) { ?>
				<tr>
					<td><?=$u_value['user_id']?></td>
					<td><?=$u_value['user_firstname']?></td>
					<td><?=$u_value['user_lastname']?></td>
					<td><a href="<?=url('admin/accounts/users/info/'.$u_value['user_id'])?>"><?=$u_value['user_email']?></a></td>
					<td><?=$u_value['user_modified']?></td>
				</tr>
			<?php }}else{ ?>
				<tr>
					<td>No Information</td>
					<td>No Information</td>
					<td>No Information</td>
					<td>No Information</td>
					<td>No Information</td>
				</tr>
			<?php } ?>
			</tbody>
		</table>
	</div>
	<?=$pagination_links?>
</div>

<?=modules::run('_main/bottom'); ?>