<?php if (!isset($meta)) $meta=''; echo modules::run('_main/top',$meta); ?>
<script>
function save_settings() {
	$.post("<?=url('_ajax/save_settings')?>",
		$("#settings_form").serialize()
	,
	function(data){
		if (data.msg==1){
			$('#msg_content').html(data.msg_data);
			$('#msg_container').removeClass('alert-danger').addClass('alert-success').show();
			$('#msg_close_button').show();
		}else{
			$('#msg_content').html(data.msg_data);
			$('#msg_container').removeClass('alert-success').addClass('alert-danger').show();
			$('#msg_close_button').show();
		}
	}, 'json');
	return false;
}
</script>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
	<ol class="breadcrumb">
	  <li><a href="<?=url('home')?>">Home</a></li>
	  <li class="active">Settings</li>
	</ol>
	<h4 class="page-header">Settings</h4>
	<div id="msg_container" class="alert alert-dismissible" role="alert" style="display:none">
	  <button id="msg_close_button" type="button" class="close" onclick="$('#msg_container').hide();" style="display:none">&times;</button>
	  <span id="msg_content"></span>
	</div>
	<div class="container-fluid well">
		<form id="settings_form" class="form-horizontal" role="form">
			<div id="div_user_language" class="form-group">
				<label for="user_language" class="col-sm-3 control-label">Default Language</label>
				<div class="col-sm-9">
					<?=$this->selects->language('user_language',' class="selectpicker"',$userinfo["user"]["user_language"])?>
				</div>
			</div>
			<div id="div_user_theme" class="form-group">
				<label for="user_language" class="col-sm-3 control-label">Default Theme</label>
				<div class="col-sm-9">
					<?=$this->selects->theme('user_theme',' class="selectpicker"',$userinfo["user"]["user_theme"])?>
				</div>
			</div>
			<div class="form-group nomarg">
				<div class="col-sm-offset-3 col-sm-9">
					<button type="button" class="btn btn-success" onclick="save_settings();">Save</button>
				</div>
			</div>
		</form>
	</div>
</div>

<?=modules::run('_main/bottom')?>