<?php if (!isset($meta)) $meta=''; echo modules::run('_main/top',$meta); ?>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
	<ol class="breadcrumb">
	  <li><a href="<?=url('home')?>">Home</a></li>
	  <li class="active">Help</li>
	</ol>
	<h4 class="page-header">Help</h4>
	<div id="error_container" class="alert alert-danger alert-dismissible" role="alert">
	  <span id="error_content">Not added yet!</span>
	</div>
</div>

<?=modules::run('_main/bottom')?>