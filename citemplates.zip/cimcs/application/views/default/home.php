<?php if (!isset($meta)) $meta=''; echo modules::run('_main/top',$meta); ?>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
	<h3 class="page-header"><?=lang('home')?></h3>
	<div class="row placeholders">
		<div class="col-xs-6 col-sm-3 placeholder">
			<h4><?=lang('my_active_tasks')?></h4>
			<span class="text-muted"><?=($stats['my_active_tasks']!='0' ? $stats['my_active_tasks'] : '0')?></span>
		</div>
		<div class="col-xs-6 col-sm-3 placeholder">
			<h4><?=lang('active_tasks')?></h4>
			<span class="text-muted"><?=($stats['active_tasks']!='0' ? $stats['active_tasks'] : '0')?></span>
		</div>
		<div class="col-xs-6 col-sm-3 placeholder">
			<h4><?=lang('active_users')?></h4>
			<span class="text-muted"><?=($stats['active_users']!='0' ? $stats['active_users'] : '0')?></span>
		</div>
	</div>
	<h4 class="sub-header"><?=($this->session->userdata('user_id')!='' ? '<a href="'.url('tasks').'">'.lang("most_recent_tasks").'</a>' : lang("most_recent_tasks"))?></h4>
	<div class="table-responsive">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>ID</th>
					<th><?=lang("description")?></th>
					<th><?=lang("creator")?></th>
					<th><?=lang("assigned_to")?></th>
					<th><?=lang("last_updated")?></th>
				</tr>
			</thead>
			<tbody>
				<?php
					if (!empty($task_data['tasks'])){
					foreach ($task_data['tasks'] as $t_key => $t_value) { ?>
					<tr>
						<td><?=$t_value['task_id']?></td>
						<td><?=$t_value['task_descr']?></td>
						<td><?=$t_value['task_creator']?></td>
						<td><?=$t_value['task_assigned']?></td>
						<td><?=$t_value['task_modified']?></td>
					</tr>
				<?php }}else{ ?>
					<tr>
						<td><?=lang("no_information")?></td>
						<td><?=lang("no_information")?></td>
						<td><?=lang("no_information")?></td>
						<td><?=lang("no_information")?></td>
						<td><?=lang("no_information")?></td>
					</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</div>

<?=modules::run('_main/bottom')?>