<?php if (!isset($meta)) $meta=''; echo modules::run('_main/top',$meta); ?>
	<script>
	function show_add_task_detail(){
		$('#new_task_detail').toggle();
	}
	function add_task_detail() {
		$.post("<?=url('_ajax/add_task_detail')?>",
			$("#new_task_detail_form").serialize()
		,
		function(data){
			if (data.msg==1){
				refresh_page();
			}else{
				$.each(data.field_data, function(f_key, f_value) {
					$("#div_"+f_key).removeClass('has-error');
					$("#"+f_key).val(f_value);
				});
				$.each(data.error_array, function(e_key, e_value) {
					$("#div_"+e_key).addClass('has-error');
				});
				$('#msg_content').html(data.msg_data);
				$('#msg_container').removeClass('alert-success').addClass('alert-danger').show();
				$('#msg_close_button').show();
			}
		}, 'json');
		return false;
	}
	function change_status(task_status) {
		$.post("<?=url('_ajax/change_task_status')?>",{
			task_status: task_status,
			task_id: "<?=$this->uri->segment(4)?>"
		},
		function(data){
			if (data.msg==1){
				refresh_page();
			}else{
				$('#msg_content').html(data.msg_data);
				$('#msg_container').removeClass('alert-success').addClass('alert-danger').show();
				$('#msg_close_button').show();
			}
		}, 'json');
	}
	</script>
	<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
		<ol class="breadcrumb">
			<li><a href="<?=url('home')?>">Home</a></li>
			<li><a href="<?=url('tasks')?>">Tasks</a></li>
			<li class="active">Task <?=$this->uri->segment(4)?></li>
		</ol>
		<h4 class="page-header">Task Details</h4>
		<h3 class="task_header"><?=$task_data['task']['task_descr']?></h3>
		<div class="dropdown">
		  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
		    <?=$this->selects->task_status('','',$task_data['task']['task_status'],1)?>
		    <span class="caret"></span>
		  </button>
		  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
			<?php if ($task_data['task']['task_status']!=0){ ?>
		    <li role="presentation"><a role="menuitem" tabindex="-1" href="javascript:change_status(0);">Waiting</a></li>
			<?php }if ($task_data['task']['task_status']!=1){ ?>
		    <li role="presentation"><a role="menuitem" tabindex="-1" href="javascript:change_status(1);">In Progress</a></li>
			<?php }if ($task_data['task']['task_status']!=2){ ?>
		    <li role="presentation"><a role="menuitem" tabindex="-1" href="javascript:change_status(2);">Complete</a></li>
			<?php } ?>
		  </ul>
		</div>
		<div class="clearfix">&nbsp;</div>
		<div id="msg_container" class="alert alert-dismissible" role="alert" style="display:none">
		  <button id="msg_close_button" type="button" class="close" onclick="$('#msg_container').hide();" style="display:none">&times;</button>
		  <span id="msg_content"></span>
		</div>
		<?php if ($this->session->flashdata('msg')=='1'){ ?>
			<div id="msg_container2" class="alert alert-success alert-dismissible" role="alert">
			  <button id="msg_close_button2" type="button" class="close" onclick="$('#msg_container2').hide();">&times;</button>
			  <span id="msg_content2"><?=$this->session->flashdata('msg_data')?></span>
			</div>
		<?php } ?>
		<div class="container-fluid well">
			<button class="btn btn-primary" type="button" onclick="show_add_task_detail();">Add new task detail</button>
			<div id="new_task_detail" style="display:none">
				<div class="clearfix">&nbsp;</div>
				<form id="new_task_detail_form" role="form">
					<input type="hidden" id="task_id" name="task_id" value="<?=$this->uri->segment(4)?>">
					<div id="div_task_detail_info" class="form-group">
						<label for="task_detail_info">Task Information</label>
						<textarea id="task_detail_info" name="task_detail_info" class="form-control" rows="3"></textarea>
					</div>
					<div id="div_task_detail_assigned" class="form-group">
						<label for="task_detail_assigned">Assign User</label>
						<p><?=$this->selects->users('task_detail_assigned',' class="selectpicker"')?></p>
					</div>
					<button type="button" class="btn btn-success" onclick="add_task_detail();">Add</button>
				</form>
			</div>
		</div>
		<?php
		if (!empty($task_detail_data['task_details'])){
		foreach ($task_detail_data['task_details'] as $t_key => $t_value) { ?>
			<div class="container-fluid well">
				<dl class="dl-horizontal" style="margin-bottom:0px">
					<dt>ID</dt><dd><?=$t_value['task_detail_id']?></dd>
					<dt>Details</dt><dd><?=$t_value['task_detail_info']?></dd>
					<dt>Author</dt><dd><?=$t_value['task_detail_author']?></dd>
					<dt>Assigned To</dt><dd><?=$t_value['task_detail_assigned']?></dd>
					<dt>Last Updated</dt><dd><?=$t_value['task_detail_modified']?></dd>
				</dl>
			</div>
		<?php }} ?>
	</div>
<?=modules::run('_main/bottom')?>