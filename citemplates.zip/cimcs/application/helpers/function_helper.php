<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* CI MCS Extension
* 
* Helper function_helper.php to be used with CI MCS Extension
* 
* @package		CI MCS Extension
* @author		Jason Davey
* @copyright	Copyright (C) 2015 Frozen Tiger Ltd.
* @license		http://www.exoiz.com/mcs_license
* @Version		3.0.0
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/

function url($uri='')
{
	$url_array = explode('/',site_url($uri));
	$x = count($url_array);
	$url = '';
	for ($i=3; $i<$x; $i++){
		$url.= '/'.$url_array[$i];
	}
	return $url;
}

function pr($array)
{  
	echo '<pre>'.print_r($array, true).'</pre>';
}

function smartQuotesUE($str,$utf8='1')
{
	if ($utf='1'){
		$smart = array("\xE2\x80\x93","\xE2\x80\x94","\xE2\x80\x98","\xE2\x80\x99","\xE2\x80\x9C","\xE2\x80\x9D","\xE2\x80\xA2","\xE2\x80\xA6");
		$replace = array('-','-','\'','\'','"','"','*','...');
	}else{
		$smart = array(chr(19),chr(24),chr(25),chr(28),chr(29));
		$replace = array('-','\'','\'','"','"');
	}
	return str_replace($smart, $replace, $str);
}

function nl2br2($text)
{
    return preg_replace("/\r\n|\n|\r/", "<br>", $text);
}

function clean_utf8($str)
{
	return  nl2br2(trim(utf8_encode(htmlentities(smartQuotesUE($str)))));
}

function is_num($num)
{
	return preg_match( '/^[0-9]+$/', $num);
}


/* End of file lang_url_helper.php */
/* Location: ./application/helper/lang_url_helper.php */