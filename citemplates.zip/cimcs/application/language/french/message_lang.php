<?php

$lang['email'] 				= "Email";
$lang['password'] 			= "Mot de passe";
$lang['sign_in'] 			= "Se connecter";
$lang['home'] 				= "Maison";
$lang['settings'] 			= "Paramètres";
$lang['profile'] 			= "Profil";
$lang['account']			= "Compte";
$lang['help'] 				= "Aidez-Moi";
$lang['admin'] 				= "Admin";
$lang['logout'] 			= "Déconnexion";
$lang['tasks'] 				= "Tâches";
$lang['export'] 			= "Exporter";
$lang['my_active_tasks'] 	= "Mes Tâches Actives";
$lang['active_tasks'] 		= "Tâches Actives";
$lang['active_users'] 		= "Utilisateurs Actifs";
$lang['most_recent_tasks'] 	= "La plupart des tâches récents";
$lang['description'] 		= "Description";
$lang['creator'] 			= "Créateur";
$lang['assigned_to'] 		= "Assigné à";
$lang['last_updated'] 		= "Mise à Jour";
$lang['no_information'] 	= "Aucune Information";

/* End of file message_lang.php */
/* Location: ./application/language/french/message_lang.php */