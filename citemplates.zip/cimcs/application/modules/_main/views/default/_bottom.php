	</div>
</div>
<script src="<?=url()?>js/jquery.min.js"></script>
<script src="<?=url()?>js/bootstrap.min.js"></script>
<script src="<?=url()?>js/bootstrap-select.js"></script>
<script src="<?=url()?>js/jquery.placeholder.js"></script>
<script type="text/javascript">
window.onload = function () {
	$('.selectpicker').selectpicker({
		style: 'btn-default form-control',
	});
	$('input, textarea').placeholder();
	$('.table-striped>tbody>tr:nth-child(odd)').css('background-color','#f9f9f9');
};
</script>
</body>
</html>