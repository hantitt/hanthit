<!DOCTYPE html>
<html lang="<?=$this->uri->segment(1)?>">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="<?=$meta['description']?>">
	<meta name="author" content="Jason Davey">
	<title>CI MCS :: <?=$meta['title']?></title>
	<link href="<?=url()?>css/normalize.css" rel="stylesheet">
	<link href="<?=url()?>css/bootstrap.min.css" rel="stylesheet">
	<link href="<?=url()?>css/bootstrap-select.css" rel="stylesheet">
	<link href="<?=url()?>css/dashboard.css" rel="stylesheet">
	<link href="<?=url()?>css/default/style.css" rel="stylesheet">
	<script src="<?=url()?>js/ie10-viewport-bug-workaround.js"></script>
	<!--[if lt IE 9]>
	<script src="<?=url()?>js/html5shiv.min.js"></script>
	<script src="<?=url()?>js/respond.min.js"></script>
	<![endif]-->
	<script src="<?=url()?>js/scripts.js"></script>
	<script>
	function refresh_page(){
		parent.location=URLDecode('<?=urlencode($_SERVER["REQUEST_URI"])?>');
	}
	function login() {
		$.post("<?=url('_ajax/login')?>",
		$("#login_form").serialize()
		,
		function(data){
			if (data.msg==1){
				parent.location='<?=url()?>'+data.msg_extra+'/home';
			}else{
				$('#main_msg_content').html(data.msg_data);
				$('#main_msg_container').removeClass('alert-success').addClass('alert-danger').show();
				$('#main_msg_close_button').show();
			}
		}, 'json');
		return false;
	}
	</script>
	</head>
	<body>
		<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<div class="logo_container">
						<a href="<?=url('home')?>"><img src="<?=url()?>images/default/eip-logo.png" alt="Logo" height="35" width="170"></a>
					</div>
				</div>
				<div class="navbar-collapse collapse">
					<?php if ($this->session->userdata('user_id')!=''){ ?>
					<ul class="nav navbar-nav navbar-right">
						<li><a href="<?=url('home')?>"><span class="glyphicon glyphicon-home nav_spacing"></span><?=lang("home")?></a></li>
						<li><a href="<?=url('settings')?>"><span class="glyphicon glyphicon-cog nav_spacing"></span><?=lang("settings")?></a></li>
						<li><a href="<?=url('profile')?>"><span class="glyphicon glyphicon-user nav_spacing"></span><?=lang("profile")?></a></li>
						<li><a href="<?=url('account')?>"><span class="glyphicon glyphicon-briefcase nav_spacing"></span><?=lang("account")?></a></li>
						<?php if ($userinfo['account']['account_admin']=='1'){ ?>
						<li><a href="<?=url('admin')?>"><span class="glyphicon glyphicon-tasks nav_spacing"></span><?=lang("admin")?></a></li>
						<?php } ?>
						<li><a href="<?=url('logout')?>"><span class="glyphicon glyphicon-lock nav_spacing"></span><?=lang("logout").' '.$userinfo['user']['user_firstname']?></a></li>
					</ul>
					<?php }else{ ?>
					<form id="login_form" class="navbar-form navbar-right" role="form">
						<div id="div_login_email" class="form-group">
							<input type="text" id="login_email" name="login_email" placeholder="<?=lang("email")?>" class="form-control">
						</div>
						<div id="div_login_password" class="form-group">
							<input type="password" id="login_password" name="login_password" placeholder="<?=lang("password")?>" class="form-control" onkeypress="if (event.keyCode==13 || event.which==13) login();">
						</div>
						<button type="button" class="btn btn-success" onclick="login();"><?=lang("sign_in")?></button>
					</form>
					<?php } ?>
				</div>
			</div>
		</div>
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-3 col-md-2 sidebar">
					<ul class="nav nav-sidebar">
						<li<?=($this->uri->segment('1')=='' ? ' class="active"' : '')?>><a href="<?=url('home')?>"><span class="glyphicon glyphicon-home nav_spacing"></span><?=lang("home")?></a></li>
					<?php if ($this->session->userdata('user_id')!=''){ ?>
						<li<?=($this->uri->segment('1')=='tasks' ? ' class="active"' : '')?>><a href="<?=url('tasks')?>"><span class="glyphicon glyphicon-list-alt nav_spacing"></span><?=lang("tasks")?> <span class="badge"><?=($stats['active_tasks']!='0' ? $stats['active_tasks'] : '')?></span></a></li>
						<?php } ?>
					</ul>
					<div class="copy-text">&copy; <a target="_blank" href="http://www.frozentiger.com">Frozen Tiger Ltd</a> <?=date('Y')?></div>
				</div>
				<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main nopad">
					<div id="main_msg_container" class="alert alert-dismissible" role="alert" style="display:none">
						<button id="main_msg_close_button" type="button" class="close" onclick="$('#main_msg_container').hide();" style="display:none">&times;</button>
						<span id="main_msg_content"></span>
					</div>
				</div>
