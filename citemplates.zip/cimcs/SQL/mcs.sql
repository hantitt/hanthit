
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE IF NOT EXISTS `accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) NOT NULL DEFAULT '/',
  `account_admin` tinyint(4) NOT NULL DEFAULT '0',
  `account_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `account_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `account_current` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

INSERT INTO `accounts` (`account_id`, `account_name`, `account_admin`, `account_created`, `account_modified`, `account_current`) VALUES
(1, 'Admin Account', 1, '2015-01-01 00:00:00', '2015-01-01 00:00:00', 1);

CREATE TABLE IF NOT EXISTS `site_settings` (
  `site_setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_setting_name` varchar(255) NOT NULL DEFAULT '/',
  `site_setting_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `site_setting_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `site_setting_current` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`site_setting_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

INSERT INTO `site_settings` (`site_setting_id`, `site_setting_name`, `site_setting_created`, `site_setting_modified`, `site_setting_current`) VALUES
(1, 'CI MCS', '2015-01-01 00:00:00', '2015-01-01 00:00:00', 1);

CREATE TABLE IF NOT EXISTS `tasks` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL DEFAULT '0',
  `task_descr` varchar(255) NOT NULL DEFAULT '/',
  `task_status` tinyint(4) NOT NULL DEFAULT '0',
  `task_creator` int(11) NOT NULL DEFAULT '0',
  `task_assigned` int(11) NOT NULL DEFAULT '0',
  `task_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `task_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `task_current` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

CREATE TABLE IF NOT EXISTS `task_details` (
  `task_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL DEFAULT '0',
  `task_id` int(11) NOT NULL,
  `task_detail_info` text,
  `task_detail_author` int(11) NOT NULL DEFAULT '0',
  `task_detail_assigned` int(11) NOT NULL DEFAULT '0',
  `task_detail_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `task_detail_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `task_detail_current` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`task_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL DEFAULT '0',
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_admin` tinyint(4) NOT NULL DEFAULT '0',
  `user_firstname` varchar(255) NOT NULL DEFAULT '/',
  `user_lastname` varchar(255) NOT NULL DEFAULT '/',
  `user_language` char(2) NOT NULL DEFAULT 'en',
  `user_theme` varchar(255) NOT NULL DEFAULT 'default',
  `user_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_current` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

INSERT INTO `users` (`user_id`, `account_id`, `user_email`, `user_password`, `user_admin`, `user_firstname`, `user_lastname`, `user_language`, `user_theme`, `user_created`, `user_modified`, `user_current`) VALUES
(1, 1, 'demo@exoiz.com', 'e7bd1e090a921de087269f9ac10336fb', 1, 'Admin', 'User', 'en', 'default', '2015-01-01 00:00:00', '2015-01-01 00:00:00', 1);
