# CodeIgniter Standard Project
by [Ben Edmunds](http://benedmunds.com)

### Included
* CodeIgniter master as a submodule
  https://github.com/EllisLab/CodeIgniter

* Ion_Auth 2 branch as a submodule
  https://github.com/benedmunds/CodeIgniter-Ion-Auth
